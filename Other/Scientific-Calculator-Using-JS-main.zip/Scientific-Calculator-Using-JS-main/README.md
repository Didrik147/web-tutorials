# Scientific-Calculator-Using-JS
This is a simple project of Vanilla JavaScript (Scientific Calculator)

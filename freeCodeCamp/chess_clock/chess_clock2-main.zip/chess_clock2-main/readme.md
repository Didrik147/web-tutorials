# Chess Clock 2

# https://chessclock.cf

![screenshot1](images/screenshot1.png)

![screenshot2](images/screenshot2.png)

![screenshot3](images/screenshot3.png)


## Sound effects by:

[Eschwabe3](https://freesound.org/people/Eschwabe3/)

License: [Creative Commons 3.0](https://creativecommons.org/licenses/by/3.0/)


[MattRuthSound](https://freesound.org/people/MattRuthSound/sounds/561660/)

License: [Creative Commons 3.0](https://creativecommons.org/licenses/by/3.0/)
